package demo3;

public class Methods {

	public static void day() {
		System.out.println("Today is saturday !");
	}

	public static void month() {
		System.out.println("It is December !");
	}

	public static void year() {
		System.out.println("It is 2016 !");
	}
}