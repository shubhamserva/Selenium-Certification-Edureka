package demo2;
import demo1.Methods;

public class Test {

	public static void main(String[] args) {
		
		Methods obj = new Methods();
		obj.day();
		obj.month();
		obj.year();
	}
}