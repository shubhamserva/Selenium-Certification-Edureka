package demo4;
import demo3.*;

public class Test {

	public static void main(String[] args) {
		
		Methods.day();
		Methods.month();
		Methods.year();
	}
}