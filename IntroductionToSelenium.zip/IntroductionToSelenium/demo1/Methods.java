package demo1;

public class Methods {

	public void day() {
		System.out.println("Today is saturday !");
	}

	public void month() {
		System.out.println("It is December !");
	}

	public void year() {
		System.out.println("It is 2016 !");
	}
}
